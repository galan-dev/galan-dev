#!/bin/bash

# This script is used to stop application
cd cd /usr/module-interview/src
pm2 stop www || true